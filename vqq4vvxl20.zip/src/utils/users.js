// Initial set of users.
export default [
  {
    id: 1,
    name: "Jennifer"
  },
  {
    id: 2,
    name: "Jane"
  },
  {
    id: 3,
    name: "John"
  }
];
